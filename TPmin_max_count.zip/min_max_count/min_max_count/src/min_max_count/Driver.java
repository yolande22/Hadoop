/*
--
TP: Programme Hadoop - calcule pour chaque age le salaire mimimum, 
								  maximum et le nombre de personne.
--
minMap.java: classe DRIVER.
*/
package min_max_count;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
//Note classe Driver (contient le main du programme Hadoop).
//Note classe Driver (contient le main du programme Hadoop).
public class Driver {
		
	// Le main du programme.
		public static void main (String[] args) throws Exception
		{	
			// Créé un object de configuration Hadoop.
			Configuration conf=new Configuration();
			// Permet à Hadoop de lire ses arguments génériques, récupère les arguments restants dans ourArgs.
			//String[] ourArgs=new GenericOptionsParser(conf, args).getRemainingArgs();
			// Obtient un nouvel objet Job: une tâche Hadoop. On fourni la configuration Hadoop ainsi qu'une description
			// textuelle de la tâche.
			Job job=Job.getInstance(conf, "Age");
			// Défini les classes driver, map et reduce.
			job.setJarByClass(Driver.class);
			job.setMapperClass(minMap.class);
			job.setReducerClass(minReduce.class);
			
			// Défini types clefs/valeurs de notre programme Hadoop.
			job.setMapOutputKeyClass(IntWritable.class);
			job.setMapOutputValueClass(DoubleWritable.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			
			// Défini les fichiers d'entrée du programme et le répertoire des résultats.
			// On se sert du premier et du deuxième argument restants pour permettre à l'utilisateur de les spécifier
			// lors de l'exécution.
			FileInputFormat.addInputPath(job,  new Path(args[0]));
			FileOutputFormat.setOutputPath(job,  new Path(args[1]));
			
			// On lance la tâche Hadoop. Si elle s'est effectuée correctement, on renvoie 0. Sinon, on renvoie -1.
			if (job.waitForCompletion(true))
				System.exit(0);
			System.exit(-1);
					
		}
	}


