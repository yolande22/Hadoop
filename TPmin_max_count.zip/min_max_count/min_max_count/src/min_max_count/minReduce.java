/*
--
TP:  Programme Hadoop - calcule pour chaque age le salaire mimimum, 
								  maximum et le nombre de personne.
--
minReduce.java: classe REDUCE.
*/
package min_max_count;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;
import java.util.Iterator;
import java.io.IOException;

//Notre classe REDUCE - templatée avec un type IntWritable pour la clef, un type de valeur DoubleWritable, et un type de retour
//(le retour final de la fonction Reduce) Text.
public class minReduce extends Reducer<IntWritable, DoubleWritable, Text, Text> 
{
	// La fonction REDUCE elle-même. Les arguments: la clef key (d'un type IntWritable), un Iterable de toutes les valeurs
		// qui sont associées à la clef en question, et le contexte Hadoop (un handle qui nous permet de renvoyer le résultat à Hadoop).
	public void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) 
						throws IOException, InterruptedException
	{
		// Pour parcourir toutes les valeurs associées à la clef fournie.
		Iterator<DoubleWritable> i=values.iterator();
		
		String chaine = "";
		
		double min=10000000.0;
		double max=0.0;
		int count=0;
		while(i.hasNext()){ // Pour chaque valeur...
			double val = i.next().get();
			
			if (val < min) 
				min=val;  // ...on recupere le minimum.
			else if (val > max)
				max=val; // ...on recupere le maximum.
			count++; // ...on compte le nombre de personne.
		}
				
		chaine = "salaire minimum:"+" "+min+" "+"  salaire maximum:"+" "+max+" "+" nombre de personne(s):"+" "+count+".";  
		// On renvoie le couple (clef;valeur) constitué de notre clef key et de la chaine de salaire minimum, maximum et count au format Text.
		context.write(new Text(key+" ans "), new Text(chaine));
				
	}
	
}