/*
--
TP: Programme Hadoop - calcule pour chaque age le salaire mimimum, 
								  maximum et le nombre de personne.
--
minMap.java: classe MAP.
*/
package min_max_count;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;

import java.util.StringTokenizer;

import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

//Notre classe MAP.
public class minMap extends Mapper<Object, Text, IntWritable, DoubleWritable>
{

	
	// La fonction MAP elle-même.
	protected void map (Object offset, Text value, Context context) 
			       throws IOException, InterruptedException
	{
		// Un StringTokenizer va nous permettre de parcourir chacun des mots de la ligne qui est passée
		// à notre opération MAP.
		StringTokenizer tok=new StringTokenizer(value.toString(), ",");
		int i=1;
		int age=0;
		double income=0.0;
		while(tok.hasMoreTokens())
		{
			String word=new String(tok.nextToken());
			if (i==2)
				// On recupere la cle qui est l'age.
				age = Integer.parseInt(word);
			else if (i == 5)
			{	
				// On recupere le revenu qui est la valeur.
				income = Double.parseDouble(word);
				// On renvoie notre couple (clef;valeur): l'age suivi du revenu).
				context.write(new IntWritable(age), new DoubleWritable(income));
			}
			i++;
			
		}
    }

}
