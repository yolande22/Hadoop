package anagram;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;

import java.util.Arrays;
import java.util.StringTokenizer;

import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

import java.io.IOException;


public class anagramMap extends Mapper<LongWritable, Text, Text, Text>
{
    
	private final static IntWritable one = new IntWritable(1);
	 private Text word = new Text();
	
	protected void map (LongWritable key, Text value, Context context) 
			       throws IOException, InterruptedException
	{
		
		StringTokenizer tok=new StringTokenizer(value.toString());
		while(tok.hasMoreTokens())
		{
			String word = tok.nextToken();
			char[] chars = word.toLowerCase().toCharArray();
			Arrays.sort(chars);
			String keys = new String (chars);
			
			context.write(new Text(keys.toLowerCase()), new Text(word.toLowerCase()));
			
		}
    }
	
}

