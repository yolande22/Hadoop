package anagram;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.OutputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;


// Notre classe Driver qui contient le main de notre programme Hadoop 
public class anagramDriver {
	
	// Le main du programme
	public static void main (String[] args) throws Exception
	{
		// creation de l'objet de configuration Hadoop
		Configuration conf=new Configuration();
		
		// creation de l'objet de configuration a partir de la configuration
		Job job=Job.getInstance(conf, "Anagram");
		
		// Definitions des classes Driver. Map et Reduce
		job.setJarByClass(anagramDriver.class);
		job.setMapperClass(anagramMap.class);
		job.setReducerClass(anagramReduce.class);
		
		// Definition des types clefs/valeurs de notre programme
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		// Definition des fichier d'entree du programme et le repertoire des resultats
		FileInputFormat.addInputPath(job,  new Path(args[0]));
		FileOutputFormat.setOutputPath(job,  new Path(args[1]));
		
		
		if (job.waitForCompletion(true))
			System.exit(0);
		System.exit(-1);
				
	}
	
	
	

}
