package anagram;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

import java.util.Iterator;
import java.io.IOException;


public class anagramReduce extends Reducer<Text, Text, Text,Text> 
{
	public void reduce(Text key, Iterable<Text> values, Context context) 
						throws IOException, InterruptedException
	{
		Iterator<Text> i=values.iterator();
		int sum = 1;
		String similarWord = "";
		while(i.hasNext())
			similarWord = similarWord +  "\t"	+i.next();
		
		context.write(new Text(key), new Text(similarWord));
		
		
	}
	

}